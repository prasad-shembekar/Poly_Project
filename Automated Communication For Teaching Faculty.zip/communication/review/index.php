<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>CAOSM</title>
<script src="http://s.codepen.io/assets/libs/modernizr.js" type="text/javascript"></script>
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

		<meta name="viewport" content="width=device-width, initial-scale=1">


<link rel="stylesheet" href="csss/reset.css">
<link rel="stylesheet" href="csss/style.css">

</head>
<style type="text/css">
	  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 100%;
        height: 100%;
      /*margin: auto;*/
  }
.carousel-inner > .item{

width: 1370px;
height: 660px;

}

</style>
<body>


  <div id="myCarousel" class="carousel slide" data-ride="carousel"  style="position: absolute;">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">

      <div class="item active">
        <img src="images/slide1.jpeg" alt="Chania"  >
        
      </div>

      <div class="item">
        <img src="images/slide2.jpeg" alt="Chania"  >
        
      </div>
    
      <div class="item">
        <img src="images/slide3.jpeg" alt="Flower" >
        
      </div>

      <div class="item">
        <img src="images/slide4.jpeg" alt="Flower" >
        
      </div>
      <div class="item">
        <img src="images/slide5.jpeg" alt="Flower" >
        
      </div>
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
     
     <div class="col-md-10 col-md-offset-1" style="margin-top: 80px; ">
         
    <section class="buttons" style="z-index: 9;position: relative;background-color: rgba(0,0,0,0.3);">
    <div class="container" >
        <h1 style="color: white;">Automated Communication Over a network for Teaching Faculty</h1>
    <a href="login.php" style="font-size:18px;color: white;" class="btn btn-2">login</a> 
    <!--End of Button 2 -->
    
    <a href="registration.php" style="font-size:18px;color: white;" class="btn btn-2">Register</a> 
    <!--End of Button 3 -->

    </div>
</section>

     </div>

<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
</body>
</html>