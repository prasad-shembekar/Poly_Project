<!-- HOME -->
<div class="btn-group">
  <a href="everyone.php">
            <button type="button" class="btn btn-default " ><span class="glyphicon glyphicon-home"></span>
              Home          
            </button>
            </a>
          </div>

<!--first button-->

        <div class="btn-group">
  					<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>
  					  Students <span class="caret"></span> 					
  					</button>
  				<ul class="dropdown-menu" role="menu">
  				  <?php if ($_SESSION["type"] == "admin") { ?> 
            <li><a href="everyone.php?tag=student_entry">Students Entry</a></li>
  				  <?php } ?>
            <li><a href="everyone.php?tag=view_students">View Students</a></li>
  				  <li><a href="everyone.php?tag=send_students_sms">Send SMS</a></li>
          </ul>
				</div>

				<?php if ($_SESSION["type"] == "admin") { ?>
				<!--second button-->
				<div class="btn-group">
  					<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>
  					  Teachers <span class="caret"></span> 					
  					</button>
  				<ul class="dropdown-menu" role="menu">
  				  <li><a href="everyone.php?tag=teachers_entry">Teachers Entry</a></li>
  				  <li><a href="everyone.php?tag=view_teachers">View Teachers</a></li>
            <li><a href="everyone.php?tag=send_teachers_sms">Send SMS</a></li>
  				</ul>
				</div>
      <?php } ?>
				
				<?php if ($_SESSION["type"] == "admin") { ?>
				<!--forth button-->
				<div class="btn-group">
  					<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-th-list"></span>
  					  Subjects <span class="caret"></span>
  					</button>
  				<ul class="dropdown-menu" role="menu">
  				  <li><a href="everyone.php?tag=subject_entry">Subjects Entry</a></li>
  				  <li><a href="everyone.php?tag=view_subjects">View Subjects</a></li>
            </ul>
				</div>
      <?php } ?>

        <!-- Gorup Chat -->
				<div class="btn-group">
            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-th-list"></span>
              Group Chat <span class="caret"></span>
            </button>
          <ul class="dropdown-menu" role="menu">
            <li><a href="everyone.php?tag=group_chat">Chat</a></li>
          </ul>
        </div>

				
				     
                               