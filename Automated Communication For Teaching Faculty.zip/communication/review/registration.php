<?php
	session_start();
	
	//require("conection/connect.php");
	
    $con = mysqli_connect("localhost","root","","automation");

	$msg="";
	if(isset($_POST['btn_sub'])){

  $f_name=$_POST['fnametxt'];
  $l_name=$_POST['lnametxt'];
  $gender=$_POST['genderrdo'];
  $dob=$_POST['yy']."/".$_POST['mm']."/".$_POST['dd'];
  $pob=$_POST['pobtxt'];
  $addr=$_POST['addrtxt'];
  $degree=$_POST['degree'];
  $salary=$_POST['slarytxt'];
  $married=$_POST['marriedrdo'];
  $phone=$_POST['phonetxt'];
  $mail=$_POST['emailtxt'];
  $password=$_POST['passwordtxt'];
  $note=$_POST['notetxt'];  
  
$md5_password = md5($password);
$type = "teacher";

$sql = "INSERT INTO teacher_tbl (f_name, l_name, gender, dob, pob, address, degree, salary, married, phone, email, password, type, note)
VALUES ('$f_name', '$l_name', '$gender', '$dob', '$pob', '$addr', '$degree', '$salary' , '$married', '$phone', '$mail', '$md5_password', '$type', '$note')";

$sql_ins=mysqli_query($con, $sql);

if($sql_ins==true){
  $msg="1 Row Inserted";  
  header("location: registration.php?action=success");
}
  
else{
  //$msg="Insert Error:".mysqli_error($con);
  header("location: registration.php?action=failure");
}

  }

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Welcome to College Management system</title>
<link rel="stylesheet" type="text/css" href="css/style_entry.css" />

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="jquery-1.11.0.js"></script>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css"/>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<link rel="stylesheet" type="text/css" href="css/home.css" />

</head>

<body>

<div class="panel panel-default">
      <div class="panel-heading"><h1><span class="glyphicon glyphicon-user"></span> Registration</h1></div>
        <div class="panel-body">
      <!-- <div class="container">
        <p style="text-align:center;">Here, you'll add new teachers detail to record into database.</p>
      </div> -->
      <?php 
if(isset($_GET['action'])) {

if($_GET['action'] == 'success') {
echo "<div style='background-color: white;padding: 20px;border: 1px solid black;margin-bottom: 25px;''>"
                . "<span class='p_font'>"
                . "You have registered successfully."
                . "</span>"
                . "</div>";
              }
else if($_GET['action'] == 'failure' ) {
echo "<div style='background-color: white;padding: 20px;border: 1px solid black;margin-bottom: 25px;''>"
                . "<span class='p_font'>"
                . "Try Again... !"
                . "</span>"
                . "</div>";
 }             

 }

 
      ?>

<div class="container_form">
  <br>
    <br>
    <form method="post">
        <div class="teacher_name_pos">
          <input type="text" name="fnametxt" class="form-control" placeholder="First name" required="" />
          <input type="text" name="lnametxt" class="form-control" placeholder="Last name" required="" />
        </div><br>
        
        <div class="teacher_radio_pos">
          <input type="radio" name="genderrdo" value="Male" checked="" > <span class="p_font">&nbsp;Male</span>
          <input type="radio" name="genderrdo" value="Female" /> <span class="p_font">&nbsp;Female</span>
        </div><br>
        
        <div class="teacher_bday_box">
          <span class="p_font">Birthday: </span>&nbsp;&nbsp;&nbsp;
          <div class="select_style">
              <select name="yy">
                  <option>Year</option>
                  <?php
              for($i=1985;$i<=2015;$i++){ 
              echo"<option value='$i'>$i</option>";
              }
            ?>
            </select>
          </div>
          
          <div class="select_style">
              <select name="mm">
                  <option>Month</option>
                  <?php
                            $mm=array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","NOv","Dec");
                            $i=0;
                            foreach($mm as $mon){
                                $i++;
                                echo"<option value='$i'> $mon</option>";    
                            }
                        ?>
                        </select>
          </div>
          
          <div class="select_style">
              <select name="dd">
                  <option>date</option>
                  <?php
                        for($i=1;$i<=31;$i++){
                        ?>
                        <option value="<?php echo $i; ?>">
                        <?php
                        if($i<10)
                            echo"0".$i;
                        else
                            echo"$i";   
            ?>
            </option> 
            <?php 
            }?>
            </select>
          </div>
          
          </div><br><br>
          
        <div class="teacher_bdayPlace_pos">
          <input type="text" name="pobtxt" class="form-control" placeholder="Place of birth" required="" />
        </div><br>
        
        <div class="teacher_address_pos">
          <input type="text" name="addrtxt" class="form-control" placeholder="Address" required="" />
        </div><br>
        
        <div class="teacher_degree_pos">
          <span class="p_font" style="float: left; margin-left: 88px;">Teacher's qualification: </span>
          <div class="select_style" style="border-left-width: 1px; margin-left: 0px; width: 102px; margin-right: 60px; margin-top: 0px; margin-bottom: 0px;">
              <select name="degree">
                  <option>Degree</option>
                  <?php
                                $mm=array("Bachelor","Master","P.HD");
                                $i=0;
                                foreach($mm as $mon){
                                    $i++;
                    echo"<option value='$mon'> $mon</option>";
                                    //echo"<option value='$i'> $mon</option>";    
                                }
                            ?>                        
                        </select>
          </div>
        </div><br>
        
        <div class="teacher_salary_pos">
          <input type="text" name="slarytxt" class="form-control" placeholder="Salary" required="" />
        </div><br>
        
        <div class="teacher_married_pos">
          <span class="p_font">Married</span>
          <input type="radio" name="marriedrdo" value="Yes"/> <span class="p_font">&nbsp;Yes</span>
          <input type="radio" name="marriedrdo" value="No"/> <span class="p_font">&nbsp;No</span>
        </div><br>
        
        <div class="teacher_mobile_pos">
          <input type="text" name="phonetxt" class="form-control" placeholder="Mobile no." required="" />
        </div><br>
        
        <div class="teacher_mail_pos">
          <input type="email" name="emailtxt" class="form-control" placeholder="Email address" />
        </div><br>
        
        <div class="teacher_note_pos">
          <input type="text" name="passwordtxt" class="form-control" placeholder="Password" required="" />
        </div><br>

        <div class="teacher_note_pos">
          <input type="text" name="notetxt" class="form-control" placeholder="Note" required="" />
        </div><br>
        
        <div class="teacher_btn_pos">
          <input type="submit" name="btn_sub" href="#" class="btn btn-primary btn-large" value="Register" />&nbsp;&nbsp;&nbsp;
          <a href="index.php" class="btn btn-primary btn-large" >Cancel</a>
        </div>
                </form>
                <br>
                <br>
      </div>
    </div>
  </div>
<div class="bottom_pos" style="margin-top: -20px;">
            <a href="AboutManagement.php" style="text-decoration: none;">About management</a>
        </div>

 
</body>
</html>