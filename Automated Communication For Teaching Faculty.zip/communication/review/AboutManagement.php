<!Doctype>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css"/>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css"/>
        <script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
        <link rel="stylesheet" type="text/css" href="css/home.c
        ss" />
        <title>Automated Communication Over a network for Teaching Faculty</title>
    </head>
    <body>
        <div class="panel panel-default">
            <div class="panel-heading"><h1 style="text-align: center;"><span class="glyphicon glyphicon-user"></span> About Project!</h1></div>
  			<div class="panel-body">
			<div class="container">
				<p style="text-align:center;">Developed By Students of Computer Engg. Department</p>
                        </div><br><br>
                        
                        <h1><strong>Project title: </strong>Automated Communication Over a network for Teaching Faculty</h1>
                        <h1><strong>Made by: Prasad & groups</strong></h1>
                        <h1><strong>College:</strong> Goverment Polytechnic Amravati </h1>
                        <h1><strong>Branch: </strong>Computer Engg.</h1>
                        </div>
        </div>
    </body>
</html>