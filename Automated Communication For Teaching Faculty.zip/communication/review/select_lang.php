<div class="btn-group">
  				<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
  				  Select Language 
  					<span class="caret"></span>
  				</button>
  				<ul class="dropdown-menu" role="menu">
   				 <li><a href="#">English</a></li>
   				 <li><a href="#">Hindi</a></li>
   				 <li class="divider">Current language</li>
                                 <li><a href="#"><strong>Selected: </strong>English</</a></li>
  				</ul>
</div>

