<?php
	  session_start();
	
	  require("conection/connect.php");
	
    $con = mysqli_connect("localhost","root","","automation");

	  $msg="";
    
    if(isset($_POST['btn_log']))
    {
		    $uname=$_POST['unametxt'];
		    $pwd=$_POST['pwdtxt'];

        $md5_password = md5($pwd);

        $qry1 = "SELECT * from users_tbl WHERE username='$uname' and password='$md5_password'";
        $rs1 = mysqli_query($con,$qry1);
        $getRowAssoc1 = mysqli_fetch_assoc($rs1);


        $qry2 = "SELECT * from teacher_tbl WHERE f_name='$uname' and password='$md5_password'";
        $rs2 = mysqli_query($con,$qry2);
        $getRowAssoc2 = mysqli_fetch_assoc($rs2);

        $cout1=mysqli_num_rows($rs1);
        $cout2=mysqli_num_rows($rs2);

        if($cout1>0)
        {
            if ($getRowAssoc1['type']=="admin") 
            {
              $_SESSION["type"] = $getRowAssoc1['type'];
              $_SESSION["u_id"] = $getRowAssoc1['u_id'];
              $_SESSION["name"] = $getRowAssoc1['username'];
              header("location: everyone.php");
            }         
        }
        else if($cout2>0)
        {
          if ($getRowAssoc2['type']=="teacher") 
          {
              if ($getRowAssoc2['subject_status']=='1') 
              {
                  $_SESSION["type"] = $getRowAssoc2['type'];
                  $_SESSION["u_id"] = $getRowAssoc2['teacher_id'];
                  $_SESSION["name"] = $getRowAssoc2['f_name'];
                  header("location: everyone.php");
              }
              else
              {
                  header("location: login.php?type=teacher_failure");
              }        
          }
        }
        else
        {
          header("location: login.php?type=failure");
        }        
    }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Welcome to Automated Communication Platform for teaching faculties only </title>
<link rel="stylesheet" type="text/css" href="css/style_entry.css" />

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="jquery-1.11.0.js"></script>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css"/>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<link rel="stylesheet" type="text/css" href="css/home.css" />

</head>

<body>

<div class="panel panel-default">
      <div class="panel-heading"><h1><span class="glyphicon glyphicon-user"></span> Login</h1></div>
        <div class="panel-body">
           <?php 
if(isset($_GET['type'])) {

if($_GET['type'] == 'failure') {
echo "<div style='background-color: white;padding: 20px;border: 1px solid black;margin-bottom: 25px;''>"
                . "<span class='p_font'>"
                . "Invalid login authentication, try again!"
                . "</span>"
                . "</div>";
}
else if($_GET['type'] == 'teacher_failure') {
echo "<div style='background-color: white;padding: 20px;border: 1px solid black;margin-bottom: 25px;''>"
                . "<span class='p_font'>"
                . "Admin not assigned you any Subject!"
                . "</span>"
                . "</div>";
 }

 }
 
 
      ?>
     
<div class="container_form" style="margin-left: 150px;">
    <br>
    <br>
    <form method="post">
        
        <div class="teacher_mail_pos">
        <div class="row">
          <div class="col-md-3">
        Username    
          </div>
          <div class="col-md-9">
          <input type="text" class="form-control" name="unametxt" placeholder="Username" title="Enter username here" />  
          </div>
        </div>
        </div><br>
        
        <div class="teacher_note_pos">
          <div class="row">
          <div class="col-md-3">
        Password    
          </div>
          <div class="col-md-9">
          <input type="password" class="form-control" name="pwdtxt" placeholder="Password" title="Enter username here" /><br>  
          </div>
        </div>
        </div>

        <div class="teacher_btn_pos">
          <a href="index.php" class="btn btn-default" >Cancel</a>
          <input type="submit" href="#" class="btn btn-default" name="btn_log" value="Sign in" style="float: right;"/>
        </div>


                </form>
                <br>
                <br>
      </div>
    </div>
  </div>
<div class="bottom_pos" style="margin-top: -20px;">
            <a href="AboutManagement.php" style="text-decoration: none;">About management</a>
        </div>

 
</body>
</html>