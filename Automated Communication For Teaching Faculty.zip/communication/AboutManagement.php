<!Doctype>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css"/>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css"/>
        <script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
        <link rel="stylesheet" type="text/css" href="css/home.css" />
        <title>Automated Communication Over a network for Teaching Faculty</title>
    </head>
    <body>
        <div class="panel panel-default">
            <div class="panel-heading"><h1 style="text-align: center;"><span class="glyphicon glyphicon-user"></span> About Project!</h1></div>
  			<div class="panel-body">
			<div class="container">
            <br>
                <p style="text-align:center;"><img src="images/Groupmember.jpeg" width="500" style="text-align: center;" height="250" onmousedown="return false;"></img></p>
				<p class="panel-heading" style="text-align:center;" >Developed By Students of Computer Engineering Department</span></p>
            </div> 
                        <h1 class="panel-heading"><strong>Project title: </strong><a href="index.php">Automated Communication Over a network for Teaching Faculty</a></h1>
                        <h1 class="panel-heading"><strong>Made by: </strong><a href="https://www.linkedin.com/in/prasad-shembekar-698b47159" target="_blank">Prasad Shembekar & Group</a></h1>
                        <h1 class="panel-heading"><strong>College:</strong><a href="http://www.gpamravati.ac.in/" target="_blank"> Goverment Polytechnic Amravati</a></h1>
                        <h1 class="panel-heading"><strong>Branch: </strong>Computer Engineering Department</h1>
            </div>
        </div>
    </body>
</html>