<?php
        $con = mysqli_connect("localhost","root","","automation");

        $user_id=$_SESSION['u_id'];

        if(isset($_POST['btn_save']))
        {

            $user_name = $_POST['name'];
            $user_id = $_POST['user_id'];
            $msg = $_POST['msg'];

            $type=$_SESSION['type'];
        
            if ($type=="admin") 
            {
                $teacher_student = '1';
            }
            else
            {
                $teacher_student = '2';   
            }

    
    
            $sql = "INSERT INTO group_chat (uid, uname, msg, teacher_student, status)
            VALUES ('$user_id', '$user_name', '$msg', '$teacher_student', '1')";    

            $sql_ins=mysqli_query($con,$sql);
        }

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style_entry.css" />

<script src="jquery.min.js"></script>

<!-- JS & CSS library of MultiSelect plugin -->
<script src="jquery.multiselect.js"></script>
<link rel="stylesheet" href="jquery.multiselect.css">

</head>

<body>

<div class="panel panel-default">
        <div class="panel-heading"><h1><span class="glyphicon glyphicon-th-list"></span> Group Chat</h1></div>
            <div class="panel-body" style="margin-left: 350px;">
                        <form method="post" enctype="multipart/form-data">    
            <div class="container">
            
            </div>

            <div class="col-md-6" style="margin-bottom:50px">
 <h1 align="center" >Group Chat</h1>
        <div id="chat_box">
        <div id="chat" ></div>
        <style>
/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
</style>
        
        
        <div class="table table-bordered table-hover" style="height: 200px; overflow-y: scroll;overflow-x: hidden;text-align: left; justify-content: center; ">
        <?php       
            $result=mysqli_query($con,"SELECT uname , msg from group_chat ORDER BY curr_date DESC Limit 0,11 ") or die ("Query 4 is inncorrect........");

            while(list($uname,$msg)= mysqli_fetch_array($result))
            {
        
                echo "
                <tr>
                <td><span style='color:green;'>$uname</span> :
                <span style='color:brown;'>$msg</span></td>
                </tr> <br>";

            }
        
        ?>
            
        </div>

        <style type="text/css">
            .btn.btn-flat {
            border-radius: 0;
            -webkit-box-shadow: none;
            -moz-box-shadow: none;
            box-shadow: none;
            border-width: 1px;
            width:420px;
}
        </style>

        <div class="col-md-12" >
        <form method="post" action="Group_chat.php" >
           
            <?php 
                $user_id=$_SESSION['u_id'];
                $type=$_SESSION['type'];
                $u_name="";

                if($type=='admin')
                {
                    $query=mysqli_query($con,"SELECT username from users_tbl where u_id='$user_id'")or die ("query 6 incorrect.......");
                    list($username)=mysqli_fetch_array($query);    
                    $u_name = $username;
                }
                else
                {
                    $query=mysqli_query($con,"SELECT f_name , l_name from teacher_tbl where teacher_id='$user_id'")or die ("query 6 incorrect.......");
                    list($f_name,$l_name)=mysqli_fetch_array($query);   
                    $u_name = $f_name." ".$l_name;
                }
             ?> 


            <input hidden="" class="input-lg" type="text" name="name" value="<?php echo $u_name;?>">
            <input hidden="" class="input-lg" type="text" name="user_id" value="
    
            <?php 
                echo $user_id=$_SESSION['u_id'];
            ?> 
"> 
            <textarea class="input-lg" name="msg" placeholder="enter message" required style="width: 440px;margin-left: -10px;"></textarea>
            <br>
            <br>
            <input class="btn btn-primary btn-flat" type="submit" name="btn_save" id="btn_save" value="Send">
</form>
</div>           
</div>
</div>


        </form>

        </div>
    </form>
</div><!-- end of style_informatios -->




<script type="text/javascript">
    /*$selectedOptions = $_POST['langOpt'];*/

    $('#langOpt').multiselect({
    columns: 1,
    placeholder: 'Select Students',
    search: true,
    selectAll: true
});

</script>

<script type="text/javascript">
    
    $(document).ready(function(){
    $('#date_time_chk').change(function(){
        if(this.checked){
            $('#date_time_input').show();
        }
        else{
            $('#date_time_input').hide();
        }

    });
});

</script>

</body>
</html>