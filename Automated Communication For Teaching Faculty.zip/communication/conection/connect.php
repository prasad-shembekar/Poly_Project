<?php
mysqli_connect("localhost", "root", "", "automation"); 
  
    if(mysqli_connect_error()) 
        echo "Connection Error."; 
//    else
//        echo "Database Connection Successfully."; 
//mysql_connect("localhost","root", "") or die("No Connection");
//mysql_select_db("assignment") or die("No Database connected!");
?>


