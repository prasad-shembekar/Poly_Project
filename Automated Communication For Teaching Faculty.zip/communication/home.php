<?php 
        $con = mysqli_connect("localhost","root","","assignment");

        $sms_pending=mysqli_query($con,"SELECT * FROM send_sms WHERE sms_pending = '1' ");

        while($row=mysqli_fetch_array($sms_pending))
        {

            $curr_date = date("Y-m-d H:i", strtotime("+4 hours +30 minutes"));

            $curr_date_timestamp = strtotime($curr_date);
            $sms_date = $row['date_txt']." ".$row['time_txt'];

            $sms_date_timestamp = strtotime($sms_date);

            if ($curr_date_timestamp >= $sms_date_timestamp) 
            {
                $sms_id= $row['id'];
                $selectedOptions= $row['ids'];
                $message= $row['message'];
                $teacher_student= $row['teacher_student'];

                $number_array = array();
                
                if ($teacher_student == '1') 
                {
                    $result_number = mysqli_query($con,"SELECT phone FROM teacher_tbl WHERE teacher_id IN (".$selectedOptions.")");
                }
                elseif ($teacher_student == '2') 
                {
                    $result_number = mysqli_query($con,"SELECT phone FROM stu_tbl WHERE stu_id IN (".$selectedOptions.")");
                }
 

                while($row2=mysqli_fetch_array($result_number))
                {
                    $number_array[]= $row2['phone'];
                }

                $implode_number_array = implode(",", $number_array);
                
                    // Authorisation details.
                    $username = "pmshembekar5@gmail.com";
                    $hash = "454826b022b6208f4bff119d915043781fb633b4f00feddfb21b76b026ca383b";
                    // Config variables. Consult http://api.textlocal.in/docs for more info.
                    $test = "0";

                    // Data for text message. This is the text message data.
                    $sender = "TXTLCL"; // This is who the message appears to be from.

                    // 612 chars or less
                    // A single number or a comma-seperated list of numbers
                    $message = urlencode($message);
                    $data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$implode_number_array."&test=".$test;
                    $ch = curl_init('http://api.textlocal.in/send/?');
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $result = curl_exec($ch); // This is the result from the API

                    $sql_update=mysqli_query($con,"UPDATE send_sms SET sms_pending = '0' WHERE id = ".$sms_id."");
            }
        }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<title>Automated Communication Over a network for teaching faculty made by Prasad Shembekar and group..</title>
</head>

<body>
	<div class="panel panel-default">
  		<div class="panel-heading"><h1>Automated Communication Platform </h1></div>
                <div class="panel-body"><br><br>
        <div>
            <img src="images/CE_IT.jpeg" width="855" style="text-align: center;" height="308" onmousedown="return false;"  />
        </div><br><br>
        <div class="middle_text">
            <p><strong>COMPUTER ENGINEERING DEPARTMENT</strong></p>
        </div>
        <div class="middle_text">
            <p><strong>VISION</strong></p>
        </div>

                
        <div class="text_para_home">
            <p><b>•</b>&nbsp;&nbsp;&nbsp;    Provide skilled professionals in Computer Engineering to contribute towards the advancement of technology useful for society and industrial environment.</p>         
        </div> 

         <div class="middle_text">
            <p><strong>MISSION</strong></p>
        </div>

                
        <div class="text_para_home" align="left" style="
  text-justify: inter-word; margin-left: 165px;">
            <p><b>•</b>&nbsp;&nbsp;&nbsp;    Impart need based and value based education by providing exposure of latest tools and technologies in the area of computer engineering to satisfy the stakeholders.
            </p>
            <p><b>•</b>&nbsp;&nbsp;&nbsp;    Upgrade and maintain facilities for quality technical education with continuous effort for excellence in Computer Engineering
            </p>
            <p><b>•</b>&nbsp;&nbsp;&nbsp;    Train students with Computer Engineering knowledge to apply it in the general disciplines of design, deployment of software and integration of existing technologies for E-governance and for benefit of society.
            </p>
            <p><b>•</b>&nbsp;&nbsp;&nbsp;    Provide a learning ambience to enhance innovations, problem solving skills, leadership qualities, team spirit and ethical responsibilities.
            </p>
            <p><b>•</b>&nbsp;&nbsp;&nbsp;    Provide an academic environment and consultancy services to the industry and society in the area of Computer engineering.
            </p>         
        </div> 

                </div>
        </div>
    
    
</body>
</html>