<?php
        $con = mysqli_connect("localhost","root","","automation");
        
        if(isset($_POST['btn_sub']))
        {
            $selectedOptions = $_POST['langOpt'];
            $implode_selectedOptions = implode(",", $selectedOptions);

            if (isset($_POST['date_time_chkbox'])) 
            {
                $date_time_chkbox='1';
                $sms_pending='1';
                $date_imput=$_POST['date_imput'];
                $time_imput=$_POST['time_imput'];   
            }
            else
            {
                $date_time_chkbox='0';
                $sms_pending='0';
                $date_imput='0';
                $time_imput='0';    
            }

            $message=$_POST['message']; 
            $teacher_student = '1';
    
            $sql = "INSERT INTO send_sms (ids, date_time_check, date_txt, time_txt, message, teacher_student, sms_pending, status)
            VALUES ('$implode_selectedOptions', '$date_time_chkbox', '$date_imput', '$time_imput', '$message', '$teacher_student', '$sms_pending', '1')";    

            $sql_ins=mysqli_query($con,$sql);
    
            if($sql_ins==true)
            {
                if (empty($_POST['date_time_chkbox'])) 
                {
                    $number_array=array();
                    $result_number = mysqli_query($con,"SELECT phone FROM teacher_tbl WHERE teacher_id IN (".implode(',',$selectedOptions).")");  
    
                    while($row=mysqli_fetch_array($result_number))
                    {
                        $number_array[]= $row['phone'];
                    }

                    $implode_number_array = implode(",", $number_array);

                    // Authorisation details.
                    $username = "pmshembekar5@gmail.com";
                    $hash = "454826b022b6208f4bff119d915043781fb633b4f00feddfb21b76b026ca383b";
                    // Config variables. Consult http://api.textlocal.in/docs for more info.
                    $test = "0";
    
                    // Data for text message. This is the text message data.
                    $sender = "TXTLCL"; // This is who the message appears to be from.
    
                    // 612 chars or less
                    // A single number or a comma-seperated list of numbers
                    $message = urlencode($message);
                    $data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$implode_number_array."&test=".$test;
                    $ch = curl_init('http://api.textlocal.in/send/?');
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $result = curl_exec($ch); // This is the result from the API
    
                    if (curl_errno($ch)) 
                    {
                        echo "<div style='background-color: white;padding: 20px;border: 1px solid black;margin-bottom: 25px;''>"
                        . "<span class='p_font'>"
                        . "error". curl_errno($ch)
                        . "</span>"
                        . "</div>";
                    }
                    else
                    {
                        echo "<div style='background-color: white;padding: 20px;border: 1px solid black;margin-bottom: 25px;''>"
                        . "<span class='p_font'>"
                        . "Message Send Successfully.... !"
                        . "</span>"
                        . "</div>";
                    }
                    curl_close($ch);
                    $msg="1 Row Inserted";
                }
                else
                {
                    echo "<div style='background-color: white;padding: 20px;border: 1px solid black;margin-bottom: 25px;''>"
                    . "<span class='p_font'>"
                    . "Message will be Send at selected Date Time."
                    . "</span>"
                    . "</div>";   
                }
            }
            else
            {
                $msg="Insert Error:".mysqli_error($con);
                echo "<div style='background-color: white;padding: 20px;border: 1px solid black;margin-bottom: 25px;''>"
                . "<span class='p_font'>"
                . $msg 
                . "</span>"
                . "</div>";
            }
        }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style_entry.css" />

<script src="jquery.min.js"></script>
<!-- JS & CSS library of MultiSelect plugin -->
<script src="jquery.multiselect.js"></script>
<link rel="stylesheet" href="jquery.multiselect.css">

</head>

<body>

<div class="panel panel-default">
  		<div class="panel-heading"><h1><span class="glyphicon glyphicon-th-list"></span> Send Teachers Sms</h1></div>
  			<div class="panel-body" style="margin-left: 150px;">
                        <form method="post" enctype="multipart/form-data">    
			<div class="container">
			
			</div>

            <br><br>

<div class="teacher_note_pos col-md-6" style="text-align:left !important">
            <select name="langOpt[]" multiple id="langOpt" required>
    <?php
                                $te_name=mysqli_query($con,"SELECT * FROM teacher_tbl");
                                while($row=mysqli_fetch_array($te_name)){
                                ?>
                                <option value="<?php echo $row['teacher_id'];?>"> <?php echo $row['f_name'] ; echo " "; echo $row['l_name'];?> </option>
                                    
                                <?php   
                                    }
                            ?>
</select>
</div>
<br>
<br>

            <div class="teacher_note_pos" style="text-align:left !important">
                 <span style="margin-left: 20px;">Date Time</span>   <input type="checkbox"  name="date_time_chkbox" id="date_time_chk" value="1" />
                </div><br>

                <div class="teacher_note_pos" style="display: none;" id="date_time_input">
                	<div class="row">
                        <div class="col-md-6">
                            <input type="date" class="form-control" name="date_imput"  />
                        </div>
                        <div class="col-md-6">
                            <input type="time" class="form-control" name="time_imput"   />
                        </div>                        
                    </div>
                </div><br>
            
                
                <div class="text_box_pos">
                	<textarea style="margin-left: -40px;width: 320px;" class="form-control" name="message" cols="23" rows="3" placeholder='Message...' required></textarea>
                </div><br><br>
            
                <div>
                	<input type="submit" class="btn btn-primary btn-large" name="btn_sub" value="Send" id="button-in"  />
                        <input type="reset" class="btn btn-primary btn-large" style="margin-left: 9px;" value="Cancel" id="button-in"/>
                </div>
           </form>
    	</div>
    </form>
</div><!-- end of style_informatios -->




<script type="text/javascript">
  

    $('#langOpt').multiselect({
    columns: 1,
    placeholder: 'Select Teacher',
    search: true,
    selectAll: true
});

</script>

<script type="text/javascript">
    
    $(document).ready(function(){
    $('#date_time_chk').change(function(){
        if(this.checked){
            $('#date_time_input').show();
        }
        else{
            $('#date_time_input').hide();
        }

    });
});

</script>

</body>
</html>