-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2020 at 09:54 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `automation`
--

-- --------------------------------------------------------

--
-- Table structure for table `group_chat`
--

CREATE TABLE `group_chat` (
  `gc_id` int(250) NOT NULL,
  `uid` int(250) NOT NULL,
  `uname` varchar(250) NOT NULL,
  `msg` longtext NOT NULL,
  `teacher_student` int(250) NOT NULL,
  `status` int(250) NOT NULL,
  `curr_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `group_chat`
--

INSERT INTO `group_chat` (`gc_id`, `uid`, `uname`, `msg`, `teacher_student`, `status`, `curr_date`) VALUES
(1, 1, 'admin  ', 'hi', 1, 1, '2020-03-02 10:23:27'),
(2, 1, 'admin  ', 'hello', 1, 1, '2020-03-02 10:23:32'),
(3, 1, 'admin  ', 'hello hi', 1, 1, '2020-03-02 10:24:01'),
(4, 1, 'admin  ', 'hu', 2, 1, '2020-03-02 10:26:19'),
(5, 1, 'Hang Han  ', 'hello', 2, 1, '2020-03-02 10:30:46'),
(6, 1, 'hiiii', 'hiiii', 1, 1, '2020-03-02 10:31:15'),
(7, 1, '', 'hello', 1, 1, '2020-03-02 10:36:11'),
(8, 1, 'admin', 'hiiiiii', 1, 1, '2020-03-02 10:36:47'),
(9, 1, 'Hang Han', 'hangg', 2, 1, '2020-03-02 10:37:04'),
(10, 1, 'Hang Han', 'hello hang', 2, 1, '2020-03-02 10:37:14'),
(11, 1, 'admin', 'aabbcc', 1, 1, '2020-03-03 11:40:50'),
(12, 1, 'admin', 'sdfsdfdtg', 1, 1, '2020-03-04 12:56:59'),
(13, 1, 'admin', 'hi\r\n', 1, 1, '2020-04-03 09:27:53'),
(14, 1, 'admin', 'hi\r\n', 1, 1, '2020-04-03 09:30:16'),
(15, 1, 'admin', 'hlo\r\n', 1, 1, '2020-04-03 09:30:23'),
(16, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:30:29'),
(17, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:31:07'),
(18, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:31:31'),
(19, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:31:52'),
(20, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:32:17'),
(21, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:32:53'),
(22, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:33:02'),
(23, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:33:10'),
(24, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:34:20'),
(25, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:34:37'),
(26, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:35:30'),
(27, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:35:41'),
(28, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:35:55'),
(29, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:36:06'),
(30, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:36:17'),
(31, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:36:30'),
(32, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:36:37'),
(33, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:36:55'),
(34, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:37:08'),
(35, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:37:35'),
(36, 1, 'admin', 'ghj', 1, 1, '2020-04-03 09:37:51'),
(37, 1, 'admin', 'hello\r\n', 1, 1, '2020-04-03 12:52:09'),
(38, 1, 'admin', 'hi', 1, 1, '2020-04-03 12:52:20'),
(39, 1, 'admin', 'hello', 1, 1, '2020-04-10 09:01:52');

-- --------------------------------------------------------

--
-- Table structure for table `send_sms`
--

CREATE TABLE `send_sms` (
  `id` int(250) NOT NULL,
  `ids` varchar(250) NOT NULL,
  `date_time_check` int(250) NOT NULL,
  `date_txt` varchar(250) NOT NULL,
  `time_txt` varchar(250) NOT NULL,
  `message` longtext NOT NULL,
  `teacher_student` int(250) NOT NULL,
  `sms_pending` int(250) NOT NULL,
  `status` int(250) NOT NULL,
  `curr_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `send_sms`
--

INSERT INTO `send_sms` (`id`, `ids`, `date_time_check`, `date_txt`, `time_txt`, `message`, `teacher_student`, `sms_pending`, `status`, `curr_date`) VALUES
(1, '1,2,3,4,5,6,7', 0, '0', '0', 'message', 1, 0, 1, '2020-03-02 07:59:08'),
(2, '1,2,3,4,5,6,7', 0, '0', '0', 'message', 1, 0, 1, '2020-03-02 08:02:38'),
(3, '1,2', 1, '2020-03-04', '13:00', 'testing message', 2, 0, 1, '2020-03-02 08:03:12'),
(4, '1,2,3,4', 0, '0', '0', 'message', 2, 0, 1, '2020-03-02 08:12:52'),
(5, '1,3', 1, '2020-03-03', '15:05', 'message', 2, 0, 1, '2020-03-02 08:13:46'),
(6, '1', 0, '0', '0', 'hellooooo', 2, 0, 1, '2020-03-02 10:25:20'),
(7, '1,2', 0, '0', '0', 'hi testing', 2, 0, 1, '2020-03-03 13:01:52'),
(8, '1', 1, '2020-03-04', '13:00', 'hello', 2, 0, 1, '2020-03-03 13:28:21'),
(9, '8', 0, '0', '0', 'hello aaaa bbbb', 1, 0, 1, '2020-03-04 08:57:14'),
(10, '9', 0, '0', '0', 'hello prasad', 1, 0, 1, '2020-03-04 13:37:53'),
(11, '11', 0, '0', '0', 'hi', 1, 0, 1, '2020-03-05 08:46:17'),
(12, '5', 1, '2020-03-05', '14:45', 'hello', 2, 0, 1, '2020-03-05 09:13:25');

-- --------------------------------------------------------

--
-- Table structure for table `stu_tbl`
--

CREATE TABLE `stu_tbl` (
  `stu_id` int(10) UNSIGNED NOT NULL,
  `rid` varchar(120) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `gender` char(10) NOT NULL,
  `dob` date NOT NULL,
  `pob` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `note` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stu_tbl`
--

INSERT INTO `stu_tbl` (`stu_id`, `rid`, `f_name`, `l_name`, `gender`, `dob`, `pob`, `address`, `phone`, `email`, `note`) VALUES
(1, '', 'Mom', 'Vannak', 'Male', '1991-03-01', 'Takeo Province', 'Phnom Penh', '7304727203', 'vannakkmum@gmail.com', 'Student'),
(2, '', 'Chon', 'Phearak', 'Male', '1990-05-04', 'Takeo Province  ', '  Phnom Penh', '9834102567', 'phearakchon@yahoo.com  ', 'Student'),
(3, '', 'Soa', 'Muny', 'Male', '1988-05-05', 'Takeo Province   ', '   Phnom Penh', '097 69 90 123', 'munysoa@gmail.com   ', 'Student'),
(4, '', 'Sok', 'Cheatha', 'Female', '1989-06-06', 'Kompot', 'Phnom Penh', '099 77 66 55 ', 'cheatasok@gmail.com', 'Student'),
(5, '', 'prasad', 'shembekar', 'Male', '1990-04-03', 'amravati', 'amravati', '7066075603', 'abc@gmail.com', 'qw'),
(6, '12', 'sushil', 'mohad', 'Male', '1997-07-15', 'yavatamal', 'samta nagar neri , ward no 6 , urjanagar', '8788075306', 'mohadsushil5@gmail.com', 'admin'),
(7, '123456', 'testing', 'sbfsd', 'Male', '2001-03-15', 'amravati', 'sdfdag', '64566', 'abc@gmail.com', 'sadasf'),
(8, '', '', '', '', '0000-00-00', '', '', '', '', ''),
(9, 'dsfsdff', 'fgfsd', 'ertre', 'Male', '1985-02-05', 'amravati', 'sdfg', 'fdsgsf', 'asas@gmail.com', 'gsfdggh');

-- --------------------------------------------------------

--
-- Table structure for table `sub_tbl`
--

CREATE TABLE `sub_tbl` (
  `sub_id` int(10) UNSIGNED NOT NULL,
  `teacher_id` int(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `sub_name` varchar(100) NOT NULL,
  `note` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_tbl`
--

INSERT INTO `sub_tbl` (`sub_id`, `teacher_id`, `semester`, `sub_name`, `note`) VALUES
(9, 6, '3', 'ertwer', '/klfdgfd,mgs.n'),
(10, 8, '3', 'qeqwe', 'asfdsffsf'),
(11, 9, '3', 'qeqwe', 'fdgfdgs'),
(12, 11, '3', 'qeqwe', 'dffh'),
(13, 3, '3', 'subject name', 'subject note'),
(14, 13, '34', 'subject name', 'subject');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_tbl`
--

CREATE TABLE `teacher_tbl` (
  `teacher_id` int(10) UNSIGNED NOT NULL,
  `f_name` varchar(30) NOT NULL,
  `l_name` varchar(30) NOT NULL,
  `gender` char(10) NOT NULL,
  `dob` date NOT NULL,
  `pob` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `degree` varchar(50) NOT NULL,
  `salary` float NOT NULL,
  `married` char(10) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL,
  `type` varchar(250) NOT NULL,
  `note` varchar(100) NOT NULL,
  `subject_status` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_tbl`
--

INSERT INTO `teacher_tbl` (`teacher_id`, `f_name`, `l_name`, `gender`, `dob`, `pob`, `address`, `degree`, `salary`, `married`, `phone`, `email`, `password`, `type`, `note`, `subject_status`) VALUES
(1, 'Hang', 'Han', 'Male', '1985-03-05', '  Kandal Province', '  Phnom Penh', 'Master', 1500, 'No', '015 871 787', 'sovannhang@gmail.com', '123', 'teacher', 'Teacher and Staff', 1),
(2, 'Pheng', 'Tola', 'Male', '1986-03-08', 'Kompong Cham Province', 'Phnom Penh', 'Bachelor', 1500, 'Yes', '016 572 393', 'tolapheng@gmail.com', '1234', 'teacher', 'Teacher and Staff', 0),
(3, 'Sann', 'Vannthoeun', 'Male', '1990-07-03', 'Kandal Province', 'kankal', 'Bachelor', 1000, 'Yes', '087 666 55 ', 'vannthoeunsann@gmail.com', '', '', 'English', 1),
(4, 'Tang', 'Hay', 'Male', '0000-00-00', 'Kroches', 'Phnom Penh', 'Bachelor', 1000, 'Yes', '099 77 66 33', 'haytang@gmail.com', '', '', 'network', 0),
(5, 'Chi', 'Kim  Y', 'Male', '0000-00-00', 'Phnom Penh', 'Phnom Penh', 'Bachelor', 1500, 'Yes', '097 66 55 423', 'kimychi@gmail.com', '', '', 'VB', 0),
(6, 'Sann', 'Sotherath', 'Male', '1985-02-01', 'Kandal Province', 'Phnom Penh', 'Bachelor', 1300, 'Yes', '012 33 44 55', 'sotherathsann@gmail.com', '', '', 'Database', 1),
(7, 'abc', 'Han', 'Male', '1985-01-01', 'h,sad', 'safasdf', 'Degree', 321, '', '', '', '', '', '', 0),
(8, 'aaaa', 'bbbb', 'Female', '1988-03-05', 'h,sad', 'safasdf', 'Bachelor', 321, 'No', '7304727203', 'asas@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', 'safdsag', 1),
(9, 'prasad', 'shembekar', 'Male', '1992-04-06', 'amravati', 'amravati', 'P.HD', 250000, 'Yes', '7066075603', 'abc@gmail.com', 'c246ad314ab52745b71bb00f4608c82a', 'teacher', 'sadasf', 1),
(10, 'prasad', 'shembekar', 'Male', '1987-03-09', 'amravati', 'amravati', 'P.HD', 0, 'Yes', '1234444', 'asas@gmail.com', 'c246ad314ab52745b71bb00f4608c82a', 'teacher', 'qsdd', 0),
(11, 'siddhand', 'khobragade', 'Male', '1990-02-04', 'amravati', 'safasdf', 'P.HD', 250000, 'No', '9604893949', 'demo@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'teacher', 'abc', 1),
(13, 'gsf', 'bbbb', 'Male', '1990-04-09', 'sdgsdg', 'amravati', 'Master', 35351, 'Yes', '64566', 'asas@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'teacher', 'qw', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users_tbl`
--

CREATE TABLE `users_tbl` (
  `u_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL,
  `type` char(10) NOT NULL,
  `note` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_tbl`
--

INSERT INTO `users_tbl` (`u_id`, `username`, `password`, `type`, `note`) VALUES
(1, 'admin', 'fcea920f7412b5da7be0cf42b8c93759', 'admin', 'creator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `group_chat`
--
ALTER TABLE `group_chat`
  ADD PRIMARY KEY (`gc_id`);

--
-- Indexes for table `send_sms`
--
ALTER TABLE `send_sms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stu_tbl`
--
ALTER TABLE `stu_tbl`
  ADD PRIMARY KEY (`stu_id`);

--
-- Indexes for table `sub_tbl`
--
ALTER TABLE `sub_tbl`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `teacher_tbl`
--
ALTER TABLE `teacher_tbl`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `users_tbl`
--
ALTER TABLE `users_tbl`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `group_chat`
--
ALTER TABLE `group_chat`
  MODIFY `gc_id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `send_sms`
--
ALTER TABLE `send_sms`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `stu_tbl`
--
ALTER TABLE `stu_tbl`
  MODIFY `stu_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `sub_tbl`
--
ALTER TABLE `sub_tbl`
  MODIFY `sub_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `teacher_tbl`
--
ALTER TABLE `teacher_tbl`
  MODIFY `teacher_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users_tbl`
--
ALTER TABLE `users_tbl`
  MODIFY `u_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
