<?php
	session_start();
    session_unset();
	session_destroy();
	require("conection/connect.php");
	header("Location: index.php");
?>
